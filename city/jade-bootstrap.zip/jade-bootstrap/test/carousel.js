var jade = require("jade");
var assert = require("assert");
var path = require("path");

describe("Carousel", function() {

});
